<html>
<head>
  <title>EventO</title>
</head>
    <div class="col-sm-1 sidenav">
       <a href="ActivityProposal-Index.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt"></span><br>Activity <br>Proposal
        </a>
        <a href="ActivityProposal-Returned.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-remove-sign"></span> <br>Returned <br> Activity <br>Proposal
        </a>
        <a href="#" class="btn btn-sml">
          <span class="glyphicon glyphicon-print"></span> <br>Report
        </a>
    </div>
</html>
