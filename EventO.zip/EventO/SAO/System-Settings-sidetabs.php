<html>
    <div class="col-sm-1 sidenav">
       <a href="System-Settings-User-Accounts.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-user" ></span> <br>User<br> Accounts
        </a>
      <a href="System-Settings-Student-Council.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt"></span> <br>Student<br>Council
        </a>
        <a href="System-Settings-System-Depart-Organization.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt"></span> <br>Org/<br>Dept
        </a>
         <!-- <a href="System-Settings-System-Config.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt"></span> <br>System<br>Config
        </a> -->
    </div>
</html>
