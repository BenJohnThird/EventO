<?php
//fetch.php
session_start();
$connect = mysqli_connect("localhost", "root", "", "ceu");
$request = mysqli_real_escape_string($connect, $_POST["query"]);
$query = "";
if($_SESSION['Position'] == 'SAO' | $_SESSION['Position'] == 'Property' || $_SESSION['Position'] == 'Maintenance' || $_SESSION['Position'] == 'TLTS')
{
	$query = "SELECT * FROM events WHERE title LIKE '%".$request."%'";
}
else
{
	$query = "SELECT *, users.Organization FROM events INNER JOIN users ON events.created = users.ID 
	where title LIKE '%".$request."%' AND users.Organization = '".$_SESSION['Organization']."'";
}
$result = mysqli_query($connect, $query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
 while($row = mysqli_fetch_assoc($result))
 {
  $data[] = $row["title"];
 }
 echo json_encode($data);
}
else
{
	 echo json_encode('');
}


?>
