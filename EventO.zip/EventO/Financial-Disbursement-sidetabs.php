	<html>
    <div class="col-sm-1 sidenav">
      <div class ="text-center">
       <a href="Financial-Disbursement-Index.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt" style="padding-right:30px;"></span><br>Disbursement
        </a>
      </div>
      <div class ="text-center">
      <a href="Financial-Disbursement-FR.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-user"></span> <br>Report
        </a>
      </div>
    </div>
</html>
