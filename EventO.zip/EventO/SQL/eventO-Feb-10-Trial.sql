-- MySQL dump 10.13  Distrib 5.7.14, for Win64 (x86_64)
--
-- Host: localhost    Database: ceu
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounting-dept`
--

DROP TABLE IF EXISTS `accounting-dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting-dept` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Rate` float DEFAULT NULL,
  `Total` float DEFAULT NULL,
  `Date` varchar(20) NOT NULL,
  `users_ID` int(11) NOT NULL,
  `ap_reservation_main_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_Accounting-dept_users1_idx` (`users_ID`),
  KEY `fk_accounting-dept_ap_reservation_main1_idx` (`ap_reservation_main_ID`),
  CONSTRAINT `fk_Accounting-dept_users1` FOREIGN KEY (`users_ID`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_accounting-dept_ap_reservation_main1` FOREIGN KEY (`ap_reservation_main_ID`) REFERENCES `ap_reservation_main` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounting-dept`
--

LOCK TABLES `accounting-dept` WRITE;
/*!40000 ALTER TABLE `accounting-dept` DISABLE KEYS */;
INSERT INTO `accounting-dept` VALUES (2,200,4000,'February 1, 2018',1,6);
/*!40000 ALTER TABLE `accounting-dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activityproposal`
--

DROP TABLE IF EXISTS `activityproposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activityproposal` (
  `ap_id` int(11) NOT NULL AUTO_INCREMENT,
  `Theme` varchar(100) DEFAULT NULL,
  `ap_status` varchar(50) DEFAULT NULL,
  `Note` varchar(255) DEFAULT NULL,
  `Type` varchar(30) DEFAULT NULL,
  `Location` varchar(10) DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `TargetParticipant` varchar(50) NOT NULL,
  `Rehearsal(TD)` varchar(100) DEFAULT NULL,
  `CountTarget` varchar(10) DEFAULT NULL,
  `ObjectivePercent` int(10) NOT NULL,
  `ValuesInculcated` varchar(100) NOT NULL,
  `PastMean` varchar(10) DEFAULT NULL,
  `PastVI` varchar(10) DEFAULT NULL,
  `BudgetType` varchar(50) NOT NULL,
  `TakenFrom` varchar(100) NOT NULL,
  `events_id` int(11) DEFAULT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`ap_id`),
  KEY `fk_activityproposal_events1_idx` (`events_id`),
  KEY `fk_activityproposal_users1_idx` (`created`),
  CONSTRAINT `fk_activityproposal_events1` FOREIGN KEY (`events_id`) REFERENCES `events` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_activityproposal_users1` FOREIGN KEY (`created`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activityproposal`
--

LOCK TABLES `activityproposal` WRITE;
/*!40000 ALTER TABLE `activityproposal` DISABLE KEYS */;
INSERT INTO `activityproposal` VALUES (2,'','Verified',NULL,'Community Outreach','Inside','another one','','','',0,'','','','','',38,6),(3,'Hi Crush','Verified | Pending Financial Report/Status	\r\n','','Community Outreach','Inside','Hi Crushh','BSIT','Monday and Tuesday','32',95,'Love','95','Passed','Requesting Subsidy for Venue(s) Only','',33,1),(5,'A gust of expertise','Verified | Pending Financial Report/Status','Go','Community Outreach','Inside','An event where all gathered to witness Mark Zuckerberg demonstrates his new app','','','',0,'Love','65','Passed','To be taken from the fund of','20000',61,1),(6,NULL,'Verified | Pending Financial Report/Status',NULL,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,NULL,'','',60,1),(7,'A silence of the night','Verified | Pending Financial Report/Status','','Community Outreach','Inside','This will show if the due date really works','BSIT and JPCS','','200',0,'Love','','','Requesting Subsidy for Venue(s) Only','',64,1),(8,NULL,'Verified',NULL,NULL,NULL,NULL,'',NULL,NULL,0,'',NULL,NULL,'','',56,1);
/*!40000 ALTER TABLE `activityproposal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_committees`
--

DROP TABLE IF EXISTS `ap_committees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_committees` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Committee` varchar(50) NOT NULL,
  `Position` varchar(50) NOT NULL,
  `Committees_Status` varchar(25) NOT NULL,
  `Stud_Emp_ID` int(11) NOT NULL,
  `ap_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_ap_committees_users1_idx` (`Stud_Emp_ID`),
  KEY `fk_ap_committees_activityproposal1_idx` (`ap_id`),
  CONSTRAINT `fk_ap_committees_activityproposal1` FOREIGN KEY (`ap_id`) REFERENCES `activityproposal` (`ap_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ap_committees_users1` FOREIGN KEY (`Stud_Emp_ID`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_committees`
--

LOCK TABLES `ap_committees` WRITE;
/*!40000 ALTER TABLE `ap_committees` DISABLE KEYS */;
INSERT INTO `ap_committees` VALUES (7,'Overall','Chairman','Done',1,3),(8,'Food','Co-Chairman','Done',1,3),(11,'Food','Member','Done',1,3),(14,'Overall','Co-Chairman','Done',6,3),(15,'Food','Chairman','Done',6,3),(16,'Overall','Chairman','Not Done',1,5),(17,'Overall','Co-Chairman','Not Done',6,5),(18,'Food','Chairman','Done',1,5),(19,'Overall','Chairman','Done',1,3);
/*!40000 ALTER TABLE `ap_committees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_consumption`
--

DROP TABLE IF EXISTS `ap_consumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_consumption` (
  `ID` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Committees` varchar(50) NOT NULL,
  `Price` float NOT NULL,
  `Description` varchar(50) NOT NULL,
  `ap_financial_disbursement_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_ap_consumption_ap_financial_disbursement1_idx` (`ap_financial_disbursement_ID`),
  CONSTRAINT `fk_ap_consumption_ap_financial_disbursement1` FOREIGN KEY (`ap_financial_disbursement_ID`) REFERENCES `ap_financial_disbursement` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_consumption`
--

LOCK TABLES `ap_consumption` WRITE;
/*!40000 ALTER TABLE `ap_consumption` DISABLE KEYS */;
INSERT INTO `ap_consumption` VALUES (00000000007,'Food',260,'Jollibee',6),(00000000009,'Materials',5,'Stapler',6),(00000000011,'Honorarium',1000,'Dota',6),(00000000012,'ProgramInvi',5000,'Lauv',6),(00000000015,'Token',1000,'Try',6),(00000000016,'Others',1000,'Try',6),(00000000017,'Others',500,'Try',6),(00000000020,'Venue',1000,'True',6),(00000000021,'Energy',500,'Meralco',6),(00000000024,'Transportation',1000,'Taxi',6);
/*!40000 ALTER TABLE `ap_consumption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_distributionbudget`
--

DROP TABLE IF EXISTS `ap_distributionbudget`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_distributionbudget` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Committees` varchar(50) NOT NULL,
  `Distributor` varchar(100) NOT NULL,
  `Amount` double NOT NULL,
  `Description` varchar(100) NOT NULL,
  `ap_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`,`ap_id`),
  KEY `fk_ap_distributionbudget_activityproposal1_idx` (`ap_id`),
  CONSTRAINT `fk_ap_distributionbudget_activityproposal1` FOREIGN KEY (`ap_id`) REFERENCES `activityproposal` (`ap_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_distributionbudget`
--

LOCK TABLES `ap_distributionbudget` WRITE;
/*!40000 ALTER TABLE `ap_distributionbudget` DISABLE KEYS */;
INSERT INTO `ap_distributionbudget` VALUES (2,'Food','JPCS',5000,'Nice',3),(6,'Materials','JPCS',100,'Nice',3),(8,'Honorarium','JPCS',100,'Nice',3),(11,'ProgramInvi','JPCS',100,'Nice',3),(13,'Token','JPCS',100,'Nice',3),(15,'Others','JPCS',100,'Nice',3),(17,'Venue','JPCS',100,'Nice',3),(19,'Energy','JPCS',100,'Nice',3),(21,'Transportation','JPCS',100,'Nice',3),(23,'Contingency','JPCS',100,'Nice',3),(25,'Food','JPCS',200000,'JPCS Fund',7),(26,'Documentation','JPCS',2000,'Nice',8),(27,'Token','JPCS',1000,'Nice',6),(29,'Contingency','CSIT',200,'Nice',3);
/*!40000 ALTER TABLE `ap_distributionbudget` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_exp_materials`
--

DROP TABLE IF EXISTS `ap_exp_materials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_exp_materials` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Category` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Price` double NOT NULL,
  `ap_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`,`ap_id`),
  KEY `fk_ap_exp_materials_activityproposal1_idx` (`ap_id`),
  CONSTRAINT `fk_ap_exp_materials_activityproposal1` FOREIGN KEY (`ap_id`) REFERENCES `activityproposal` (`ap_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_exp_materials`
--

LOCK TABLES `ap_exp_materials` WRITE;
/*!40000 ALTER TABLE `ap_exp_materials` DISABLE KEYS */;
INSERT INTO `ap_exp_materials` VALUES (1,'Publicity','Print',20,3),(3,'Registration','Print',5,3),(4,'Registration','print',5,3),(5,'Registration','print',5,3);
/*!40000 ALTER TABLE `ap_exp_materials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_expenses`
--

DROP TABLE IF EXISTS `ap_expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_expenses` (
  `ID` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Committees` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Pcs` float NOT NULL,
  `Price` float NOT NULL,
  `Description` varchar(50) NOT NULL,
  `ap_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`,`ap_id`),
  KEY `fk_ap_expenses_activityproposal1_idx` (`ap_id`),
  CONSTRAINT `fk_ap_expenses_activityproposal1` FOREIGN KEY (`ap_id`) REFERENCES `activityproposal` (`ap_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_expenses`
--

LOCK TABLES `ap_expenses` WRITE;
/*!40000 ALTER TABLE `ap_expenses` DISABLE KEYS */;
INSERT INTO `ap_expenses` VALUES (00000000003,'Token','CSGO Champion',1,1000,'CSIT Day',3),(00000000004,'Token','Dota Champion',1,1000,'CSIT Day',3),(00000000005,'Token','Programming Champion',1,400,'CSIT Day',3),(00000000007,'Documentation','Stapler',5,500,'Little Town',3),(00000000008,'Documentation','Print',250,5,'Print',3),(00000000009,'Food','Jollibee',50,85,'Affordable',3),(00000000010,'Documentation','Xerox',50,0.5,'7th Floor',3),(00000000012,'Food','Jollibee',10,100,'For guests',3),(00000000015,'Food','Jollibee',1,1000,'For King',3),(00000000016,'Food','KFC',1,2000,'For Queen',3),(00000000023,'ProgramInvi','Print',30,500,'Print',3),(00000000026,'Contingency','Contingency',1,500,'If ever',3),(00000000029,'Documentation','Pin',25,30,'Little Town',5),(00000000030,'Food','Itallianis',100,2000,'For Facebook Guests',5),(00000000031,'Food','Giligans',200,2000,'Nice',7),(00000000035,'Others','Grab',3,200,'Contestant',3),(00000000036,'Venue','Pasig Covered Court',1,200,'Nice',3),(00000000037,'Energy','Energy Fee',1,2505,'SAC GP',3),(00000000038,'Transportation','Bus',3,200,'CEU',3);
/*!40000 ALTER TABLE `ap_expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_financial_disbursement`
--

DROP TABLE IF EXISTS `ap_financial_disbursement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_financial_disbursement` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ap_financial_disbursement_status` varchar(45) DEFAULT NULL,
  `ap_financial_disbursement_notes` varchar(255) DEFAULT NULL,
  `ap_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_ap_financial_disbursement_activityproposal1_idx` (`ap_id`),
  CONSTRAINT `fk_ap_financial_disbursement_activityproposal1` FOREIGN KEY (`ap_id`) REFERENCES `activityproposal` (`ap_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_financial_disbursement`
--

LOCK TABLES `ap_financial_disbursement` WRITE;
/*!40000 ALTER TABLE `ap_financial_disbursement` DISABLE KEYS */;
INSERT INTO `ap_financial_disbursement` VALUES (6,'Pending','Bennn',3),(7,'Pending','Bennnn',5),(8,'Pending','',6),(9,'Pending','',7),(10,'Pending','',7);
/*!40000 ALTER TABLE `ap_financial_disbursement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_financial_report`
--

DROP TABLE IF EXISTS `ap_financial_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_financial_report` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ap_financial_report_status` varchar(45) DEFAULT NULL,
  `ap_financial_report_notes` varchar(255) DEFAULT NULL,
  `ap_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_ap_financial_report_activityproposal1_idx` (`ap_id`),
  CONSTRAINT `fk_ap_financial_report_activityproposal1` FOREIGN KEY (`ap_id`) REFERENCES `activityproposal` (`ap_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_financial_report`
--

LOCK TABLES `ap_financial_report` WRITE;
/*!40000 ALTER TABLE `ap_financial_report` DISABLE KEYS */;
INSERT INTO `ap_financial_report` VALUES (1,'Pending','Ben',3),(2,'Pending','',5),(3,'Pending','',6),(4,'Pending','',7),(5,'Pending','',7);
/*!40000 ALTER TABLE `ap_financial_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_guest`
--

DROP TABLE IF EXISTS `ap_guest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_guest` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Position` varchar(255) NOT NULL,
  `Educ_Attainment` varchar(255) NOT NULL,
  `Exp_Train` varchar(255) NOT NULL,
  `ap_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`,`ap_id`),
  KEY `fk_ap_guest_activityproposal1_idx` (`ap_id`),
  CONSTRAINT `fk_ap_guest_activityproposal1` FOREIGN KEY (`ap_id`) REFERENCES `activityproposal` (`ap_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_guest`
--

LOCK TABLES `ap_guest` WRITE;
/*!40000 ALTER TABLE `ap_guest` DISABLE KEYS */;
INSERT INTO `ap_guest` VALUES (1,'Ben John C. Villanueva III','CEO','Cum Laude','Pro Web Developer/Programmer',3),(2,'Mary Aissen Avisado','CEO','Cum Laude','MNS',3),(6,'Mark Zuckerberg','CEO','Nice','Facebook',5),(7,' Ben John C. Villanueva III','CEO','Cum Laude','Boss',7);
/*!40000 ALTER TABLE `ap_guest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_objectives`
--

DROP TABLE IF EXISTS `ap_objectives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_objectives` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Objectives` varchar(255) NOT NULL,
  `events_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_ap_objectives_events1_idx` (`events_id`),
  CONSTRAINT `fk_ap_objectives_events1` FOREIGN KEY (`events_id`) REFERENCES `events` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_objectives`
--

LOCK TABLES `ap_objectives` WRITE;
/*!40000 ALTER TABLE `ap_objectives` DISABLE KEYS */;
/*!40000 ALTER TABLE `ap_objectives` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_reservation`
--

DROP TABLE IF EXISTS `ap_reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_reservation` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Subject` varchar(70) NOT NULL,
  `Pcs` varchar(20) NOT NULL,
  `Sector` varchar(50) NOT NULL,
  `ap_reservation_main_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_ap_reservation_ap_reservation_main1_idx` (`ap_reservation_main_ID`),
  CONSTRAINT `fk_ap_reservation_ap_reservation_main1` FOREIGN KEY (`ap_reservation_main_ID`) REFERENCES `ap_reservation_main` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_reservation`
--

LOCK TABLES `ap_reservation` WRITE;
/*!40000 ALTER TABLE `ap_reservation` DISABLE KEYS */;
INSERT INTO `ap_reservation` VALUES (4,'Chair','3','Physical Facilities',6),(6,'Laptop/Wide Screen','1','TLTS',6),(9,'CD/Casette Player','3','TLTS',6),(11,'DVD/VCD Player','3','TLTS',6),(12,'Lecture Style','1','Classroom',6),(13,'Chair','200','Physical Facilities',10),(14,'Laptop/Wide Screen','1','TLTS',10),(15,'Microphone/Karaoke','2','TLTS',10),(17,'Square Style','1','Classroom',9),(19,'Lecture Style','1','Classroom',8);
/*!40000 ALTER TABLE `ap_reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_reservation_main`
--

DROP TABLE IF EXISTS `ap_reservation_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_reservation_main` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_status` varchar(45) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `ap_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_ap_reservation_main_activityproposal1_idx` (`ap_id`),
  CONSTRAINT `fk_ap_reservation_main_activityproposal1` FOREIGN KEY (`ap_id`) REFERENCES `activityproposal` (`ap_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_reservation_main`
--

LOCK TABLES `ap_reservation_main` WRITE;
/*!40000 ALTER TABLE `ap_reservation_main` DISABLE KEYS */;
INSERT INTO `ap_reservation_main` VALUES (6,'Verified by Property','Bennn',3),(7,'Verified by TLTS',NULL,2),(8,'Pending','',5),(9,'Pending','',6),(10,'Verified by Property','',7);
/*!40000 ALTER TABLE `ap_reservation_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ap_schedule`
--

DROP TABLE IF EXISTS `ap_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ap_schedule` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Activity` varchar(60) NOT NULL,
  `Starttime` varchar(50) NOT NULL,
  `Endtime` varchar(50) NOT NULL,
  `Person_Group` varchar(70) NOT NULL,
  `ap_id` int(11) NOT NULL,
  PRIMARY KEY (`ID`,`ap_id`),
  KEY `fk_ap_schedule_activityproposal1_idx` (`ap_id`),
  CONSTRAINT `fk_ap_schedule_activityproposal1` FOREIGN KEY (`ap_id`) REFERENCES `activityproposal` (`ap_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ap_schedule`
--

LOCK TABLES `ap_schedule` WRITE;
/*!40000 ALTER TABLE `ap_schedule` DISABLE KEYS */;
INSERT INTO `ap_schedule` VALUES (3,'Class','10:00','15:00','Mr. Marcial Anacio',5),(6,'Registration','07:00','07:10','Jane Doe',7),(7,'Opening Remarks','07:10','07:20','Mr. Marcial Anacio',7),(9,'Closing Remarks','10:30','10:40','Sir Mac',3),(10,'Registration','10:10','10:20','Gli',3);
/*!40000 ALTER TABLE `ap_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `department_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'CSIT'),(2,'HRM');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `place` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `proponent` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `situation` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `sy` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `notes` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `created` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_events_users1_idx` (`created`),
  CONSTRAINT `fk_events_users1` FOREIGN KEY (`created`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (33,'Mary','','2018-01-24 13:30:00','2018-01-24 13:30:00','CEU SAC GP','Me','Pending Activity Proposal','','Crushhh',1),(38,'Another one','','2018-01-26 13:30:00','2018-01-26 13:30:00','another one','JPCS','Verified','2017-2018','',6),(56,'CSIT Day','','2018-01-25 07:00:00','2018-01-25 12:00:00','9th Floor, 901 and 902','JPCS','Pending Activity Proposal','2017-2018','We have already changed it. Thank you.',1),(57,'CSIT Day','','2018-01-26 13:30:00','2018-01-27 16:00:00','9th Floor, 901 and 902','JPCS','Pending','2017-2018','Awardingg',1),(60,'Nathan Ganesh','','2018-01-22 01:00:00','2018-01-22 03:00:00','Ben','Ben','Pending Activity Proposal','2017-2018','Done',1),(61,'Ben','','2018-01-22 01:00:00','2018-01-22 03:00:00','Red','Ben','Pending Activity Proposal','2017-2018','',1),(62,'Try','','2018-01-26 01:00:00','2018-01-27 13:00:00','Try','JPCS','Verified','2017-2018','',1),(63,'JPCS Week','','2018-01-27 08:00:00','2018-01-27 16:30:00','9th Floor','CSIT','Returned','2017-2018','Change your color to orange please. Thank you.',6),(64,'Trying Due Date','','2018-02-10 07:00:00','2018-02-10 11:00:00','9th Floor','JPCS','Pending Activity Proposal','2017-2018','Good',1),(65,'Yow','','2018-02-22 01:00:00','2018-02-23 13:00:00','Ben','CSIT','Pending','2017-2018','',6);
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `history`
--

DROP TABLE IF EXISTS `history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Function` varchar(30) DEFAULT NULL,
  `Time` datetime DEFAULT NULL,
  `users_ID` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_history_users1_idx1` (`users_ID`),
  CONSTRAINT `fk_history_users1` FOREIGN KEY (`users_ID`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `history`
--

LOCK TABLES `history` WRITE;
/*!40000 ALTER TABLE `history` DISABLE KEYS */;
/*!40000 ALTER TABLE `history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_users`
--

DROP TABLE IF EXISTS `mobile_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_users` (
  `Userno` varchar(50) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(45) DEFAULT NULL,
  `department_ID` int(11) NOT NULL,
  PRIMARY KEY (`Userno`),
  KEY `fk_mobile_users_department1_idx` (`department_ID`),
  CONSTRAINT `fk_mobile_users_department1` FOREIGN KEY (`department_ID`) REFERENCES `department` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_users`
--

LOCK TABLES `mobile_users` WRITE;
/*!40000 ALTER TABLE `mobile_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mobile_users_has_organization`
--

DROP TABLE IF EXISTS `mobile_users_has_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mobile_users_has_organization` (
  `mobile_users_Userno` varchar(50) NOT NULL,
  `organization_ID` int(11) NOT NULL,
  PRIMARY KEY (`mobile_users_Userno`,`organization_ID`),
  KEY `fk_mobile_users_has_organization_organization1_idx` (`organization_ID`),
  KEY `fk_mobile_users_has_organization_mobile_users1_idx` (`mobile_users_Userno`),
  CONSTRAINT `fk_mobile_users_has_organization_mobile_users1` FOREIGN KEY (`mobile_users_Userno`) REFERENCES `mobile_users` (`Userno`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_mobile_users_has_organization_organization1` FOREIGN KEY (`organization_ID`) REFERENCES `organization` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mobile_users_has_organization`
--

LOCK TABLES `mobile_users_has_organization` WRITE;
/*!40000 ALTER TABLE `mobile_users_has_organization` DISABLE KEYS */;
/*!40000 ALTER TABLE `mobile_users_has_organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization`
--

DROP TABLE IF EXISTS `organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `organization_name` varchar(150) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization`
--

LOCK TABLES `organization` WRITE;
/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` VALUES (1,'CSIT SC'),(2,'JPCS SC');
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_has_department`
--

DROP TABLE IF EXISTS `organization_has_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_has_department` (
  `organization_ID` int(11) NOT NULL,
  `department_ID` int(11) NOT NULL,
  PRIMARY KEY (`organization_ID`,`department_ID`),
  KEY `fk_organization_has_department_department1_idx` (`department_ID`),
  KEY `fk_organization_has_department_organization1_idx` (`organization_ID`),
  CONSTRAINT `fk_organization_has_department_department1` FOREIGN KEY (`department_ID`) REFERENCES `department` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_organization_has_department_organization1` FOREIGN KEY (`organization_ID`) REFERENCES `organization` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_has_department`
--

LOCK TABLES `organization_has_department` WRITE;
/*!40000 ALTER TABLE `organization_has_department` DISABLE KEYS */;
INSERT INTO `organization_has_department` VALUES (1,1),(2,1);
/*!40000 ALTER TABLE `organization_has_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `physicalfaci-dept`
--

DROP TABLE IF EXISTS `physicalfaci-dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `physicalfaci-dept` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Rate` float DEFAULT NULL,
  `Date` date DEFAULT NULL,
  `physical_start` time NOT NULL,
  `physical_end` time NOT NULL,
  `Pcs` int(10) DEFAULT NULL,
  `Request` varchar(50) NOT NULL,
  `users_ID` int(11) NOT NULL,
  `ap_reservation_main_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_PhysicalFaci-dept_users1_idx` (`users_ID`),
  KEY `fk_physicalfaci-dept_ap_reservation_main1_idx` (`ap_reservation_main_ID`),
  CONSTRAINT `fk_PhysicalFaci-dept_users1` FOREIGN KEY (`users_ID`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_physicalfaci-dept_ap_reservation_main1` FOREIGN KEY (`ap_reservation_main_ID`) REFERENCES `ap_reservation_main` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `physicalfaci-dept`
--

LOCK TABLES `physicalfaci-dept` WRITE;
/*!40000 ALTER TABLE `physicalfaci-dept` DISABLE KEYS */;
INSERT INTO `physicalfaci-dept` VALUES (1,2000,'2018-01-31','14:30:00','15:30:00',6,'BMS',1,6),(2,200,'2018-01-31','14:30:00','15:30:00',3,'PPFD',1,6);
/*!40000 ALTER TABLE `physicalfaci-dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Lastname` varchar(50) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Middlename` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Organization` varchar(50) NOT NULL,
  `Position` varchar(50) NOT NULL,
  `UserLvl` varchar(50) NOT NULL,
  `AccessLvl` varchar(50) NOT NULL,
  `department_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_users_department1_idx` (`department_ID`),
  CONSTRAINT `fk_users_department1` FOREIGN KEY (`department_ID`) REFERENCES `department` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Ben','812d6a01ed0d3508196055be1b62e3a952f9d51be9fdc1b175d5cb9f2aed838fa18958819eeff033e38da19518741ac60494f5c4e41536d730afaca7b18b4cee','villanuevabenjohn@gmail.com','Villanueva','Ben John III','Cabual','BSIT','CSIT','Student Council','Student','User',0),(5,'Super Admin','4d6ef00694648a2cd4797a02e3d7484d9246d074d1c8e14eece96afb4848c219098cf2cc7d76b7821781c4a5b50e9e9324da3fc52415db7e0d10540c2f6ad58d','superadmin@gmail.com','Super Admin','Super Admin','Super Admin','SAO','SAO','SAO','Employee','Super Admin',0),(6,'Mary','72c2f664fed9fb38b5cd0e40f1f5fb153c75e7270c7250ea4147ee4b7fe4bdc4264f2c0db7acec1679e51da8e18379345bb3fcf103b177d07e3f3e1581dc86d0','Mary@gmail.com','Avisado','Mary Aissen','Howard','BSIT','JPCS','Student Council','Student','User',0),(7,'Marie','812d6a01ed0d3508196055be1b62e3a952f9d51be9fdc1b175d5cb9f2aed838fa18958819eeff033e38da19518741ac60494f5c4e41536d730afaca7b18b4cee','Marie@gmail.com','Cruz','Marie','Lloyd','SAO','SAO','SAO','Employee','User',0),(8,'Mac','533e8ddca766af6b8e81a53020d69f885a95fae67286d4322341cfc0ca3cb2efd5073e2875ac46e010ab32b0d51e2deb13756f1a03c696e03898ce6ff8d05ae1','marcial@gmail.com','Anacio','Marcial','Cruz','BSIT','CSIT','Organization Adviser','Employee','Admin',0),(9,'Maintenance','7e0591400107f641411ea4ceda726c3833a0f49ca39e3fa581ea25677796501b24e2f857dbc36e283cedfa9a5ce4104758327c3b3ea363c300049944967e7b1f','Maintenance@gmail.com','Doe','Jane','Cruz','Maintenance','Maintenance','Maintenance','Employee','User',0),(10,'Property','4559ed258c06ab05dc92a08e218279c64336b4f70a2819c251652c0380f2d9947e934b9c58aed3e862d2f08b22c1c26fd04ff3a097ad585dcb28b1c0c5344459','Property@gmail.com','Doe','John','Cruz','Property','Property','Property','Employee','User',0),(11,'TLTS','688f1ca6c58c00f6f0bdea49b27b097d84b049a750ad8714d6ad73fe380a4bd392fdb8acf4420335449a67caa09de6f303ba4db5a1211f8443fddcb54162e87a','TLTS@gmail.com','Doe','James','Cruz','TLTS','TLST','TLTS','Employee','User',0),(12,'Dummy','Dummy','Dummy@gmail.com','Dummy','Dummy','Dummy','Dummy','Dummy','','Employee','User',0),(13,'Razer','Razer','Razer@gmail.com','Razer','Razer','Razer','BSCS','JPCS','Student Council','Student','User',0),(20,'AbDon34','ac75b08c584d41be890a49db2e532f2877c84cbd2285bb713c303f8e5538f3c0fb4eed44b5a0bc2f3620b0e746e71e41929f118d3063019efc1218a23b366528','villanuevabenjohn@gmail.com','Villanueva','Ben John III','Cabual','BSIT','CSIT','Student Council','Student','User',0),(22,'Alabaster','d4501bf2f4a3718fee76036a2852c04b9eccffb1a352959d493d9bd1382191468322114771d70edc0306fe7f7b2a24ea4c7b3e58b08b52a6ebf133ebc12fd1bb','Jar@gmail.com','Alabaster','Jar','Alabaster','Maintenance','Maintenance','Maintenance','Employee','User',0),(23,'Aiyan','Aiyan','aiyan@gmail.com','Villalon','Aiyan Zak','De Castro','CSIT','CSIT SC','Student Council','Student','User',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_has_organization`
--

DROP TABLE IF EXISTS `users_has_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_has_organization` (
  `users_ID` int(11) NOT NULL,
  `organization_ID` int(11) NOT NULL,
  `users_position` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`users_ID`,`organization_ID`),
  KEY `fk_users_has_organization_organization1_idx` (`organization_ID`),
  KEY `fk_users_has_organization_users1_idx` (`users_ID`),
  CONSTRAINT `fk_users_has_organization_organization1` FOREIGN KEY (`organization_ID`) REFERENCES `organization` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_has_organization_users1` FOREIGN KEY (`users_ID`) REFERENCES `users` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_has_organization`
--

LOCK TABLES `users_has_organization` WRITE;
/*!40000 ALTER TABLE `users_has_organization` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_has_organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ceu'
--

--
-- Dumping routines for database 'ceu'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-02-10 14:05:03
