<?php
include ('Connection.php');


// SELECT SA ORGANIZATION HAHANAPIN YUNG NAME
$sqlSelectOrg = "SELECT * FROM organization where ID ='".$_POST["organization"]."'";
$result = mysqli_query($conn,$sqlSelectOrg);
if(mysqli_num_rows($result) > 0)
{
	while($row = mysqli_fetch_array($result))
	{
		// KAPAG WALA PANG LAMAN YUNG ORG, MAG UUPDATE
		if($row["organization_adviser"] == "")
		{
			$sqlUpdate = "UPDATE `organization` SET organization_adviser = '".$_POST["id"]."' where ID ='".$_POST["organization"]."'";
			if(mysqli_query($conn, $sqlUpdate))   
			 {  
				 echo "Organization Added";
			 }  
			else
			{
				echo "Error Occured";
			}
		}
		// KAPAG MAY LAMAN NA
		else
		{
			echo 'Organization has now a Organization Adviser';
		}
	}
}
else
{
	echo "The organization selected is not in database";
}
 
?>
