<?php
include ('../Connection.php');
$id = $_POST["id"];
$Date= date('Y-m-d H:i:s');
 $sql = "UPDATE `events` SET `situation`='".$_POST["situation"]."' WHERE id = '".$id."'";
 if(mysqli_query($conn, $sql))
 {
	 echo "Data Updated";
 }
else
{
	echo "Error Occured";
}
 ?>
