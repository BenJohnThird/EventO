<html>
    <div class="col-sm-1 sidenav">
        <a href="agenda-views.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-calendar"></span> <br>Calendar
        </a>
       <a href="ActionPlan-AP.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt" style="padding-right:15px;"></span> <br>Action Plan
        </a>
      <a href="ActionPlan-Returned.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-remove-sign"></span> <br>Returned
        </a>
        <a href="#" class="btn btn-sml">
          <span class="glyphicon glyphicon-print"></span> <br>Report
        </a>
    </div>
</html>