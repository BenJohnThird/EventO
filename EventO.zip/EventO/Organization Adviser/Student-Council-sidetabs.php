<html>
    <div class="col-sm-1 sidenav">
       <a href="Student-Council-Index.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-user" ></span> <br>Current<br> Council
        </a>
      <a href="Student-Council-SC.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt"></span> <br>Student<br>Council
        </a>
        <a href="Student-Council-Organization-Setting.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt"></span> <br>Org<br>Setting
        </a>
    </div>
</html>
