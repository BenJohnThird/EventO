<?php
include('Connection.php');
$output = '';
$sql = "SELECT * FROM ap_committees where Committee LIKE 'Overall%' and ap_id = '".$_POST["id"]."'";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) > 0 )
{
	echo '<table class = "table">
		<thead>
			<tr>
				<th colspan = "3" class = "text-center"><kbd>Overall</kbd> Working Committees</th>
			</tr>
			<tr>
				<th>Position</th>
				<th>Student/Faculty</th>
				<th>Functions</th>
			</tr>
		</thead>';
	while($row = mysqli_fetch_array($result))
	{
		echo '
			<tbody>
			<tr>
					<td  data-idpass ="'.$row["ID"].'">' .$row["Position"].'</td>
					<td  data-idpass ="'.$row["ID"].'">';

					$sqlshow = "SELECT * FROM users where ID = '".$row["Stud_Emp_ID"]."'";
					$resultUser = mysqli_query($conn, $sqlshow);
					if(mysqli_num_rows($resultUser) > 0 )
					{
						while($rowUser = mysqli_fetch_array($resultUser))
						{
							//echo "$rowUser["Lastname"].",".$rowUser["Firstname"];	
							echo $rowUser["Lastname"] ."," .  $rowUser["Firstname"];
						}
					}
					echo '</td>
					<td>
					<button name = "btn_del-Committees-Overall" id ="btn_del-Committees-Overall" data-idunique = "'.$row["ID"].'">Delete</button>
					</td>
			</tr>';
	}
	echo '
			<tr>
				<td>
					<select class="form-control" id="committees-overall-position">
					    <option>Chairman</option>
					    <option>Co-Chairman</option>
					    <option>Faculty</option>
					    <option>Co-Faculty</option>
					</select>
				</td>
				<td>
					<select class="form-control" id="committees-overall-person">
					    ';
					    	session_start();
					    	$sqlUser = "SELECT * FROM users where Department = '".$_SESSION['Course']."'";
					    	$resultUser = mysqli_query($conn, $sqlUser);
							if(mysqli_num_rows($resultUser) > 0 )
							{
								while($rowUser = mysqli_fetch_array($resultUser))
								{
									echo "<option value = '".$rowUser["ID"]."'>".$rowUser["Lastname"].",".$rowUser["Firstname"]."</option>";	
								}
							}
					    echo'
					</select>
				</td>
				<td><button name = "btn_add-Committees-Overall" id ="btn_add-Committees-Overall" data-id6 = "'.$_POST["id"].'">Add</button></td>
			</tr>
		</tbody>';
}
else
{
	echo '<table class = "table">
		<thead>
			<tr>
				<th colspan = "3" class = "text-center"><kbd>Overall</kbd> Working Committees</th>
			</tr>
			<tr>
				<th>Position</th>
				<th>Student/Faculty</th>
				<th>Functions</th>
			</tr>
		</thead>';
	echo '
		<tbody>
			<tr>
				<td>
					<select class="form-control" id="committees-overall-position">
					    <option>Chairman</option>
					    <option>Co-Chairman</option>
					    <option>Faculty</option>
					    <option>Co-Faculty</option>
					</select>
				</td>
				<td>
					<select class="form-control" id="committees-overall-person">
					    ';
					    	$sqlUser = "SELECT * FROM users where Department = 'BSIT'";
					    	$resultUser = mysqli_query($conn, $sqlUser);
							if(mysqli_num_rows($resultUser) > 0 )
							{
								while($rowUser = mysqli_fetch_array($resultUser))
								{
									echo "<option value = '".$rowUser["ID"]."'>".$rowUser["Lastname"].",".$rowUser["Firstname"]."</option>";	
								}
							}
					    echo'
					</select>
				</td>
				<td><button name = "btn_add-Committees-Overall" id ="btn_add-Committees-Overall" data-id6 = "'.$_POST["id"].'">Add</button></td>
			</tr>
		</tbody>';
}
echo '</table>';
	
?>