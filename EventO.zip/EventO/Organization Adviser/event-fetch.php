<?php
//fetch.php
session_start();
$connect = mysqli_connect("localhost", "root", "", "ceu");
$request = mysqli_real_escape_string($connect, $_POST["query"]);
$query = "";
if($_SESSION['Position'] == 'SAO')
{
	$query = "SELECT * FROM events WHERE title LIKE '%".$request."%'";
	console.log('Ben');
}
else
{
	$query = "SELECT * FROM events INNER JOIN users ON events.created = users.ID
			INNER JOIN users_has_organization ON users.ID = users_has_organization.users_ID
			where title LIKE '%".$request."%' 
			AND users_has_organization.organization_ID = '".$_SESSION['OrganizationInWords']."' group by title";
}
$result = mysqli_query($connect, $query);

$data = array();

if(mysqli_num_rows($result) > 0)
{
 while($row = mysqli_fetch_assoc($result))
 {
  $data[] = $row["title"];
 }
 echo json_encode($data);
}
else
{
	 echo json_encode('');
}


?>
