	<html>
    <div class="col-sm-1 sidenav">
      <div class ="text-center">
       <a href="Financial-Status-Index.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt"></span><br>Financial<br>Status
        </a>
      </div>
      <div class ="text-center">
      <a href="Financial-Status-Year-End-Report.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-user"></span> <br>Year-end<br>Report
        </a>
      </div>
    </div>
</html>
