<html>
    <div class="col-sm-1 sidenav">
       <a href="Event-Index.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-list-alt" style="padding-right:15px;"></span> <br>Reservation
        </a>
      <a href="Event-Committees.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-user" style="padding-right:15px;"></span> <br>Committees
        </a>
        <a href="Event-Report.php" class="btn btn-sml">
          <span class="glyphicon glyphicon-print"></span> <br>Report
        </a>
    </div>
</html>
